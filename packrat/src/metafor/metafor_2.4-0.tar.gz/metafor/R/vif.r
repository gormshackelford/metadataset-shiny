vif <- function(x, ...)
   UseMethod("vif")
