cooks.distance.rma.uni <- function(model, progbar=FALSE, ...)
   influence(model, progbar=progbar, measure="cooks.distance", ...)
