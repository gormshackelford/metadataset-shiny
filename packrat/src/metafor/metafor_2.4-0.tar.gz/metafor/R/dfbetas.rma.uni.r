dfbetas.rma.uni <- function(model, progbar=FALSE, ...)
   influence(model, progbar=progbar, measure="dfbetas", ...)
