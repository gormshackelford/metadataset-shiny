rstudent.rma.uni <- function(model, digits, progbar=FALSE, ...)
   influence(model, digits=digits, progbar=progbar, measure="rstudent", ...)
