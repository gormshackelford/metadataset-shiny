regtest <- function(x, ...)
   UseMethod("regtest")
