metafor.news <- function()
   news(package="metafor")
