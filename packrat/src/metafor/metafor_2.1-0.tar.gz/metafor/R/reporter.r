reporter <- function(x, ...)
   UseMethod("reporter")
